function ChatList() {
  return <div>채팅 리스트 입니다.</div>;
}

export default ChatList;
