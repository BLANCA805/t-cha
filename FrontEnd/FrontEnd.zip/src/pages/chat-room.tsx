function ChatRoom() {
  return <div>채팅 화면 입니다.</div>;
}

export default ChatRoom;
