// export const api = "http://i9a805.p.ssafy.io:8090";

// export const api = "http://70.12.247.244:8080";

export const api = "https://www.tcha.site/api";
