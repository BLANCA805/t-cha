function ErrorPage() {
  return <p>존재하지 않는 페이지입니다.</p>;
}

export default ErrorPage;
